package com.example.japan_pratica3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
